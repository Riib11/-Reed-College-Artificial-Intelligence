# Project 1: Search

To my great dismay, I was able to satisfy all tests except for `test_cases/q7/food_heuristic_11.test`. My heuristic for finding food is is obviously not trivial. However, it seems to fail to be admissible. The heuristic does work for all the relevant test layouts, however.